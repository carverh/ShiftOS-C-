config = {
	["location"] = "top",
	["al_entries"] = "/Shiftum42/_applauncher"
}